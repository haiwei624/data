dotted lines connect siblings / solid lines connect a parent and a child
