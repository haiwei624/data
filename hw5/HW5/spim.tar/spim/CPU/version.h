#define SPIM_VERSION "Version 9.1.12 of December 14, 2013"
